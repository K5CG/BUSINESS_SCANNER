import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as esbuild from 'esbuild';
import type { AnyDocument } from '../types';
import { QA_CORPUS_DIRS } from '../lib/qa-corpus-12';
import type { LatestQaFixture } from '../lib/qa-latest-fixtures';

const PACKAGE_ID = 'com.mybizscanner.ai';

function collectFixtures(): Array<{
  id: string;
  title: string;
  documentType: string;
  pages: LatestQaFixture['pages'];
  qaDir: string;
}> {
  const out = [];
  for (const qaDir of QA_CORPUS_DIRS) {
    const fixtureDir = path.join(process.cwd(), qaDir, 'fixtures');
    if (!fs.existsSync(path.join(fixtureDir, 'index.json'))) continue;
    const index = JSON.parse(fs.readFileSync(path.join(fixtureDir, 'index.json'), 'utf8')) as {
      documents: Array<{ id: string }>;
    };
    for (const entry of index.documents) {
      const fixture = JSON.parse(
        fs.readFileSync(path.join(fixtureDir, `${entry.id}.json`), 'utf8'),
      ) as LatestQaFixture;
      out.push({
        id: fixture.id,
        title: fixture.title,
        documentType: fixture.type === 'business_card' ? 'free_document' : fixture.type,
        pages: fixture.pages,
        qaDir,
      });
    }
  }
  return out;
}

function findHermesBin(): string | null {
  if (process.env.HERMES_BIN && fs.existsSync(process.env.HERMES_BIN)) return process.env.HERMES_BIN;
  const roots = [
    path.join(process.cwd(), '.tmp-qa', 'hermes-cli', 'hermes.exe'),
    path.join(process.cwd(), '.tmp-qa', 'hermes-cli', 'bin', 'hermes.exe'),
    path.join(process.cwd(), 'node_modules', 'hermes-compiler'),
    path.join(os.homedir(), 'AppData', 'Local', 'Android', 'Sdk'),
  ];
  const names = process.platform === 'win32'
    ? ['hermes.exe', 'hermesc.exe']
    : ['hermes', 'hermesc'];
  const stack = [...roots];
  while (stack.length > 0) {
    const dir = stack.pop();
    if (!dir || !fs.existsSync(dir)) continue;
    const stat = fs.statSync(dir);
    if (stat.isFile() && names.includes(path.basename(dir))) return dir;
    let entries: fs.Dirent[] = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isFile() && names.includes(entry.name)) return full;
      if (entry.isDirectory() && !/android|intermediates|transforms/i.test(entry.name)) {
        stack.push(full);
      }
    }
  }
  return null;
}

async function bundleReplay(fixtures: ReturnType<typeof collectFixtures>, outfile: string): Promise<void> {
  const prelude = `var __HERMES_REPLAY__ = true;
var __QA_FIXTURES__ = ${JSON.stringify(fixtures.map(({ qaDir, ...rest }) => rest))};
if (typeof print !== 'function') { var print = function(text) { if (typeof console !== 'undefined') console.log(text); }; }
if (typeof console === 'undefined') {
  var console = {
    log: function() { print(Array.prototype.slice.call(arguments).join(' ')); },
    warn: function() { print(Array.prototype.slice.call(arguments).join(' ')); },
    error: function() { print(Array.prototype.slice.call(arguments).join(' ')); },
    info: function() { print(Array.prototype.slice.call(arguments).join(' ')); },
    debug: function() { print(Array.prototype.slice.call(arguments).join(' ')); },
    table: function() {},
  };
}
if (typeof setTimeout !== 'function') { var setTimeout = function(fn) { fn(); return 0; }; }
if (typeof setImmediate !== 'function') { var setImmediate = setTimeout; }
if (typeof process === 'undefined') { var process = { env: {}, argv: [] }; }
if (typeof queueMicrotask !== 'function' && typeof Promise !== 'undefined') {
  var queueMicrotask = function(fn) { Promise.resolve().then(fn); };
}
`;
  await esbuild.build({
    entryPoints: [path.join(process.cwd(), 'scripts', 'hermes-replay-entry.ts')],
    bundle: true,
    format: 'iife',
    platform: 'neutral',
    outfile,
    banner: { js: prelude },
    alias: {
      'expo-file-system': path.join(process.cwd(), 'tests', 'stubs', 'expo-file-system-legacy-stub.ts'),
      'expo-file-system/legacy': path.join(process.cwd(), 'tests', 'stubs', 'expo-file-system-legacy-stub.ts'),
      'expo-modules-core': path.join(process.cwd(), 'scripts', 'stub-expo-modules-core.mjs'),
      'react-native': path.join(process.cwd(), 'tests', 'stubs', 'react-native-image-stub.ts'),
    },
    logLevel: 'silent',
  });
  const bundled = fs.readFileSync(outfile, 'utf8');
  fs.writeFileSync(outfile, rewriteClassExpressionsForHermes(bundled));
}

function rewriteClassExpressionsForHermes(source: string): string {
  const needle = /var (\w+) = class extends (\w+) \{/g;
  let output = '';
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = needle.exec(source))) {
    const name = match[1];
    const parent = match[2];
    const openBrace = match.index + match[0].length - 1;
    let depth = 0;
    let end = openBrace;
    for (; end < source.length; end += 1) {
      if (source[end] === '{') depth += 1;
      else if (source[end] === '}') {
        depth -= 1;
        if (depth === 0) {
          end += 1;
          if (source[end] === ';') end += 1;
          break;
        }
      }
    }
    const body = source.slice(openBrace + 1, source[end - 1] === ';' ? end - 2 : end - 1);
    const ctorMatch = body.match(/constructor\s*\(([^)]*)\)\s*\{/);
    const args = ctorMatch?.[1] ?? '';
    let ctorBody = '';
    if (ctorMatch) {
      const ctorOpen = body.indexOf(ctorMatch[0]) + ctorMatch[0].length - 1;
      let ctorDepth = 0;
      let ctorEnd = ctorOpen;
      for (; ctorEnd < body.length; ctorEnd += 1) {
        if (body[ctorEnd] === '{') ctorDepth += 1;
        else if (body[ctorEnd] === '}') {
          ctorDepth -= 1;
          if (ctorDepth === 0) break;
        }
      }
      ctorBody = body.slice(ctorOpen + 1, ctorEnd);
    }
    const superMatch = ctorBody.match(/super\s*\(([\s\S]*?)\)\s*;?/);
    const superArgs = superMatch?.[1] ?? '';
    const rest = ctorBody.replace(/super\s*\([\s\S]*?\)\s*;?/, '').replace(/\bthis\b/g, '_this');
    output += source.slice(lastIndex, match.index);
    output += `var ${name} = (function () {
  function ${name}(${args}) {
    var _this = new ${parent}(${superArgs});
    if (Object.setPrototypeOf) Object.setPrototypeOf(_this, ${name}.prototype);
    else _this.__proto__ = ${name}.prototype;
    ${rest}
    return _this;
  }
  ${name}.prototype = Object.create(${parent}.prototype);
  ${name}.prototype.constructor = ${name};
  return ${name};
})();`;
    lastIndex = end;
    needle.lastIndex = end;
  }
  return output + source.slice(lastIndex);
}

function writeSnapshots(qaDir: string, results: Array<{ id: string; title: string; snapshot: unknown }>): void {
  const outDir = path.join(process.cwd(), qaDir, 'hermes-snapshots');
  fs.mkdirSync(outDir, { recursive: true });
  for (const result of results) {
    fs.writeFileSync(path.join(outDir, `${result.id}.json`), JSON.stringify(result, null, 2));
  }
}

async function runLocalHermes(): Promise<boolean> {
  const fixtures = collectFixtures();
  if (fixtures.length === 0) {
    console.error('NO_QA_FIXTURES');
    return false;
  }
  const hermes = findHermesBin();
  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'hermes-replay-'));
  const bundlePath = path.join(workDir, 'replay.js');
  await bundleReplay(fixtures, bundlePath);
  if (!hermes) {
    console.error('HERMES_BIN_MISSING');
    console.error(`Bundled parser at ${bundlePath} but no Hermes VM was found.`);
    return false;
  }
  const ran = spawnSync(hermes, [bundlePath], {
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
    timeout: 180_000,
  });
  if (ran.status !== 0) {
    console.error(ran.stderr || ran.stdout || 'HERMES_REPLAY_FAILED');
    return false;
  }
  const stdout = ran.stdout.trim();
  const marker = 'HERMES_REPLAY_RESULT:';
  const marked = stdout.lastIndexOf(marker);
  const payload = marked >= 0
    ? stdout.slice(marked + marker.length).trim()
    : stdout.slice(stdout.lastIndexOf('{'));
  const parsed = JSON.parse(payload) as {
    runtime?: string;
    results?: Array<{ id: string; title: string; snapshot: unknown }>;
    error?: string;
    stack?: string;
  };
  if (parsed.runtime !== 'hermes' || !parsed.results) {
    console.error('HERMES_RUNTIME_NOT_DETECTED', JSON.stringify(parsed).slice(0, 4000));
    return false;
  }
  const byId = new Map(fixtures.map((fixture) => [fixture.id, fixture.qaDir]));
  const grouped = new Map<string, typeof parsed.results>();
  for (const result of parsed.results) {
    const qaDir = byId.get(result.id);
    if (!qaDir) continue;
    const list = grouped.get(qaDir) ?? [];
    list.push(result);
    grouped.set(qaDir, list);
  }
  for (const [qaDir, results] of grouped) {
    writeSnapshots(qaDir, results ?? []);
    fs.writeFileSync(
      path.join(process.cwd(), qaDir, 'hermes-replay-result.json'),
      JSON.stringify({ runtime: 'hermes', results }, null, 2),
    );
  }
  console.log(`Hermes replay ${parsed.results.length}/${fixtures.length}`);
  return parsed.results.length === fixtures.length;
}

function mainAndroidFallback(): void {
  const documents: AnyDocument[] = [];
  for (const qaDir of QA_CORPUS_DIRS) {
    const fixtureDir = path.join(process.cwd(), qaDir, 'fixtures');
    if (!fs.existsSync(path.join(fixtureDir, 'index.json'))) continue;
    const index = JSON.parse(fs.readFileSync(path.join(fixtureDir, 'index.json'), 'utf8')) as {
      documents: Array<{ id: string }>;
    };
    for (const entry of index.documents) {
      documents.push(JSON.parse(
        fs.readFileSync(path.join(fixtureDir, `${entry.id}.document.json`), 'utf8'),
      ) as AnyDocument);
    }
  }
  const requestPath = path.join(process.cwd(), QA_CORPUS_DIRS[0], 'qa-replay-request.json');
  fs.writeFileSync(requestPath, JSON.stringify({ deadlineMode: 'production', documents }));
  console.log(`Wrote ${requestPath} (${documents.length} documents). Launch android-qa-fixture-replay.ts on a connected device.`);
}

async function main(): Promise<void> {
  const ok = await runLocalHermes();
  if (!ok) mainAndroidFallback();
  process.exitCode = ok ? 0 : 2;
}

void main();

